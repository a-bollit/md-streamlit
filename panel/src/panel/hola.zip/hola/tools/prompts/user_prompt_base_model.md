"""
Devolver el modelo de datos completo y una descripcion resumida de los atributos a partir del nombre de la tabla, utilizando una herramienta para buscar en un documento. El nombre que vas a recibir el usado en un codigo de oracle forms, dentro del documento se utiliza otro nombre pero el mismo documento da la equivalencia, buscala. Dado el nombre de la tabla tienes que buscar en la tabla de equivalencias que dado su nombre buscar a que codigo esta asocidado, con formato EXPE_T***, busca ese nombre y utilizalo. Dado ese codigo debes buscar toda informacion del modelo de datos que encuentres.


"""