"""
Necesito información detallada sobre {question} extraída de la documentación disponible. Por favor, busca en todos los documentos técnicos relevantes y proporciona una respuesta completa, incluyendo ejemplos de código, detalles técnicos y cualquier información adicional que sea útil para entender y aplicar {question} correctamente en un contexto de desarrollo de software. Toda funcionalidad debe tener un componente especifico en Mova, buscalo y describelo.


"""